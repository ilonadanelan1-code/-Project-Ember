# Changelog — Project Ember

## v0.4.0 — First city and economy loop

- Added the first playable capital, Stone Ford (`Каменный Брод`), on the strategic hex map.
- Added a mobile-friendly city panel accessible through the map button or the capital tile.
- Added city population, food, gold and stored production.
- Added per-turn city income and simple population growth from stored food.
- Added a shared production queue for buildings and recruited units.
- Added four buildings: Farm (+5 food/turn), Market (+4 gold/turn), Workshop (+3 production/turn) and Barracks (unlocks recruitment).
- Added recruitment of Swordsmen and Archers; completed recruits join the player's strategic army.
- Added a 16-unit army cap and gold/production costs for buildings and recruits.
- Added queue status, completed/queued building states, recruit availability feedback and a scrollable city panel for phone-sized screens.
- Kept recruited armies within tactical battlefield bounds when spawning larger unit rosters.
- Preserved v0.3.0 campaign-save compatibility by adding defaults for city data when older saves are loaded.
- Updated README, Android start guide, design document and roadmap.

### Economy rules in this prototype

- Starting city resources: 120 gold, 8 food and 0 stored production; population starts at 5.
- Base income per turn: +2 food, +4 gold and +4 production.
- Every 12 stored food adds one citizen, up to 20 population.
- Farm: 25 gold / 5 production; +5 food per turn.
- Market: 35 gold / 6 production; +4 gold per turn.
- Workshop: 45 gold / 8 production; +3 production per turn.
- Barracks: 50 gold / 8 production; unlocks unit recruitment.
- Swordsman: 20 gold / 3 production; joins with 125 HP.
- Archer: 24 gold / 4 production; joins with 72 HP.
- Production is accumulated at the end of each campaign turn and spent sequentially on the queue. Gold is charged when an item is queued.

## v0.3.0 — Strategic map and battle connection

- Added 37-hex strategic map with plains, forests, hills and impassable water.
- Added player and neutral armies with turn-based movement.
- Added enemy approach behavior and transition into the tactical battle scene.
- Added battle result transfer back to the campaign, including surviving unit roles and health.
- Added campaign persistence in `user://project_ember_campaign.json`.

## v0.2.0 — Tactical battle package

- Added target highlighting, retreat orders and low-health enemy retreat behavior.
- Added pause, battle speed control and camera zoom.
- Added battle summary with time, losses, kills and damage.

## v0.1.5 — Formations

- Added line, column and wedge formation orders.

## v0.1.4 — Unit roles

- Added melee swordsmen, ranged archers, projectile visuals and ranged spacing.

## v0.1.3 — Command behavior

- Improved Hold and Stop orders and unit spacing.

## v0.1.2 — Touch interface

- Improved touch handling, on-screen command UI and health bars.

## v0.1.1 — First Android prototype

- First tactical test with two primitive armies and touch-oriented commands.
