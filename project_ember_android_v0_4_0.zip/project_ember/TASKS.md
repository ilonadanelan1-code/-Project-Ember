# Project Ember — Tasks

## v0.4.0 delivered in source (runtime check still needed)

- [x] City panel on the strategic map.
- [x] Food, gold, production and population state.
- [x] Per-turn income and simple population growth.
- [x] Four building types and sequential construction queue.
- [x] Barracks unlocks Swordsman / Archer recruitment.
- [x] Recruits join the campaign army after production completes.
- [x] City state and queues persist in the campaign save.
- [x] v0.3.0 save compatibility through default city data.
- [x] Android setup and city loop documentation.

## First target-device verification

- [ ] Import v0.4.0 in Godot Android Editor.
- [ ] Open city panel from the bottom button.
- [ ] Queue a Farm and pass turns until it completes.
- [ ] Confirm food income changes after construction.
- [ ] Queue Barracks and wait for completion.
- [ ] Recruit a swordsman and confirm army count increases.
- [ ] Start a tactical battle and confirm the recruited unit appears.
- [ ] Restart the app and confirm city/resources/army persist.

## Next development batch

- [ ] Add a city unit roster and clearer production progress display.
- [ ] Make map markers distinguish army, capital and neutral locations at a glance.
- [ ] Add an additional neutral camp / resource site.
- [ ] Add a settler and founding of a second city after the current loop is verified.
