# Android Start — Project Ember v0.4.0

## Installing the project

1. Download the complete ZIP archive `project_ember_android_v0_4_0.zip`.
2. In Android Files, extract it into a new folder, for example `project_ember_v0_4_0`.
3. Open Godot Android Editor.
4. On the Projects screen, tap Import.
5. Select `project.godot` inside the extracted `project_ember` folder.
6. Wait for import to finish, then press Play.

Keep the previous folder as a backup. Do not extract this release over the previous project folder.

## First city loop

1. The first city, `Каменный Брод`, is already present on the strategic map. The capital is marked with a gold `C`.
2. Tap `ОТКРЫТЬ ГОРОД` on the bottom panel, or tap the capital tile. The city panel can scroll vertically on smaller screens.
3. Review population, food, gold, production and the current queue.
4. Queue one or more buildings. Gold is spent immediately; production is applied at the end of each turn.
5. Build the Barracks to unlock recruitment.
6. Queue Swordsmen or Archers. When their production cost is completed, the new unit joins the player's strategic army.
7. Close the city panel, move the army and continue the strategic campaign.

## City buildings

- Farm: 25 gold, 5 production; +5 food per turn.
- Market: 35 gold, 6 production; +4 gold per turn.
- Workshop: 45 gold, 8 production; +3 production per turn.
- Barracks: 50 gold, 8 production; unlocks recruitment.

## Recruitment

- Swordsman: 20 gold, 3 production; 125 HP.
- Archer: 24 gold, 4 production; 72 HP.
- Army capacity: 16 individual units.

## Economy

- Starting resources: 120 gold, 8 food and 0 stored production; population 5.
- Base income per turn: +2 food, +4 gold and +4 production.
- Every 12 stored food adds one citizen, up to 20 population.
- Buildings and recruits share one sequential production queue. Gold is charged when an order is added; production is spent as it accumulates each turn.

## Strategic map controls

- `P` — player army.
- `!` — neutral enemy army.
- `C` — capital city.
- Tap `P` or `ВЫБРАТЬ АРМИЮ`, then tap a neighboring passable hex to move.
- Tap `ОТКРЫТЬ ГОРОД` to manage the capital.
- Tap `СЛЕДУЮЩИЙ ХОД` to collect city income and move the neutral army.
- When the enemy is adjacent, tap `АТАКОВАТЬ` to enter the tactical battle.
- After battle, return to the map; surviving units and their health remain in the army.

## Saves

Campaign data is saved to `user://project_ember_campaign.json`. v0.4.0 reads v0.3.0 saves and supplies default city data for older campaigns. A fresh campaign resets armies, city resources and the building queue.

## Important test status

The project files and referenced resources were checked statically and the ZIP archive integrity is checked before delivery. Godot is not installed in the build environment, so a headless engine run cannot be claimed. First run this release in Godot Android Editor on the target phone.
