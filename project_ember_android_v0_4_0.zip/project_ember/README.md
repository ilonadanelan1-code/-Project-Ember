# Project Ember

Mobile-friendly Fantasy 4X Strategy + Tactical Real-time Combat prototype built with Godot 4.x / GDScript.

## Current version: v0.4.0 — First playable city loop

The project now links a strategic hex map, persistent campaign armies, tactical real-time battles and a first city economy. The capital `Каменный Брод` is present from the start. The player can queue buildings, collect resources over campaign turns, unlock barracks and recruit new melee or ranged units into the strategic army.

## What's playable

### Strategic map and campaign

- 37 axial hexes with plains, forests, hills and impassable water.
- Player army and neutral enemy army.
- One neighboring-hex movement per player turn.
- Basic neutral-army approach behavior.
- Encounters transition into the tactical battle scene.
- Tactical survivors and their remaining health are transferred back into the strategic army; eliminated units remain losses.
- Campaign autosave to `user://project_ember_campaign.json`.

### City

- First capital `Каменный Брод`, marked with a gold `C` on the map.
- Scrollable mobile city panel with population, food, gold, stored production, income and queue.
- Base income: +2 food, +4 gold and +4 production each turn.
- Every 12 stored food adds one citizen, up to 20 population.
- Farm: 25 gold / 5 production; +5 food per turn.
- Market: 35 gold / 6 production; +4 gold per turn.
- Workshop: 45 gold / 8 production; +3 production per turn.
- Barracks: 50 gold / 8 production; unlocks unit recruitment.
- Shared sequential production queue. Gold is paid when the order is queued; stored production completes orders at the end of turns.
- Swordsman recruitment: 20 gold / 3 production; 125 HP.
- Archer recruitment: 24 gold / 4 production; 72 HP.
- Maximum strategic army size: 16 individual units.

### Tactical battle

- Primitive 3D melee and ranged units.
- Touch selection, additive selection and direct movement/attack orders.
- Attack-Move, Hold, Stop and Retreat orders.
- Line, column and wedge formations.
- Melee swordsmen and ranged archers with visible projectile travel.
- Health bars, focus-target ring, pause, speed control and camera zoom.
- Battle results include duration, losses, kills and damage.

## Project structure

- `project.godot` — project settings, startup scene and CampaignState autoload.
- `scripts/campaign_state.gd` — persistent campaign, city economy, queues and battle handoff.
- `scripts/strategy_map.gd` — hex map, movement, neutral AI and mobile city UI.
- `scripts/combat_test.gd` — tactical battle and result screen.
- `scripts/battle_unit.gd` — unit roles, movement, attacks and health.
- `scripts/combat_projectile.gd` — visible ranged projectiles.
- `scenes/strategy_map.tscn` — startup strategy scene.
- `scenes/combat_test.tscn` — tactical scene.

## Android run

1. Extract the full ZIP to a new folder.
2. Open Godot Android Editor.
3. Tap Import and choose `project.godot` in the extracted `project_ember` folder.
4. Wait for asset import and press Play.

See `ANDROID_START.md` for the first city/build/recruit loop.

## Scope notes

The first city is pre-placed for the vertical slice. Settler-based founding of additional cities, additional factions, diplomacy, heroes, a larger procedural world and final visual assets are not implemented yet.

## Validation status

The file tree, scene/script paths, resource references and ZIP integrity are checked statically. No Godot executable is installed in the build environment, so this release has not been runtime-tested here. The target-device check is still required.
