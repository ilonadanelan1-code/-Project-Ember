# Project Ember — Roadmap

## Current state — v0.4.0

A connected mobile prototype containing:

- tactical real-time combat with two unit roles, formations, touch commands and battle results;
- 37-hex strategic map, turn-based army movement, neutral enemy approach and battle transitions;
- persistent campaign army records and health after tactical combat;
- one pre-placed capital with food, gold, production, population, construction queue, barracks and recruitment.

## Next milestones

### 1. Verify and stabilize the connected loop

- Run v0.4.0 in Godot Android Editor.
- Confirm city panel input and readability on the phone.
- Confirm production queue and autosave across app restart.
- Confirm recruited units appear in the next tactical battle.
- Fix only issues observed in runtime tests.

### 2. Improve strategy map and settlement play

- More map space and terrain variety.
- Settler unit and founding of additional cities.
- City influence / ownership around nearby hexes.
- Basic resource sites and neutral camps.

### 3. Improve armies and tactical combat

- Army composition display and unit roster.
- Better formations, target priorities and combat feedback.
- Basic hero unit as an army leader.

### 4. Basic AI kingdom

- Expand neutral army behavior into a small AI faction.
- AI city and army growth.
- Simple war/peace state.

### 5. Later systems

- Heroes, leveling and equipment.
- Diplomacy and trade.
- Procedural world generation options.
- Art, sound and UI polish.

## Scope discipline

The immediate goal is not to add every 4X system. First make the connected city → army → battle loop stable and enjoyable on the target Android device.
